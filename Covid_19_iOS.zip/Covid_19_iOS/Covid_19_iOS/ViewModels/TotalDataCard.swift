//
//  TotalDataCard.swift
//  Covid_19_iOS
//
//  Created by Brian Rouse on 4/25/20.
//  Copyright © 2020 Brian Rouse. All rights reserved.
//

import SwiftUI

struct TotalDataCard: View {
    
    var number: String = "Error"
    var name: String = "Confirm"
    var color: Color = .primary
    
    
    
    var body: some View {
        
        GeometryReader { geometry in
            
            VStack {
                Text(self.number)
                    .font(.subheadline)
                    .padding(5)
                    .foregroundColor(self.color)
                
                Text(self.name)
                .font(.body)
                .padding(5)
                .foregroundColor(self.color)

            }//End VStack
                .frame(width: geometry.size.width, height: 80, alignment: .center)
                .background(Color("cardBackgroundGray"))
                .cornerRadius(8.0)
            
            
        }//End Geometry
       
    }
}

struct TotalDataCard_Previews: PreviewProvider {
    static var previews: some View {
        TotalDataCard()
    }
}
