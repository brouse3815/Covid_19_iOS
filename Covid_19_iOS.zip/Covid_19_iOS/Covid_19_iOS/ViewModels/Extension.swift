//
//  Extension.swift
//  Covid_19_iOS
//
//  Created by Brian Rouse on 4/25/20.
//  Copyright © 2020 Brian Rouse. All rights reserved.
//

import Foundation
extension Int {
    
    func formatNumber() -> String {
        let formatter = NumberFormatter()
        formatter.groupingSeparator = ","
        formatter.numberStyle = .decimal
        return formatter.string(from: NSNumber(value: self))!
        
    }
}

extension Int64 {
    
    func formatNumber() -> String {
        let formatter = NumberFormatter()
        formatter.groupingSeparator = ","
        formatter.numberStyle = .decimal
        return formatter.string(from: NSNumber(value: self))!
        
    }
}

