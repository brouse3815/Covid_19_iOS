//
//  CountryDetailRow.swift
//  Covid_19_iOS
//
//  Created by Brian Rouse on 4/25/20.
//  Copyright © 2020 Brian Rouse. All rights reserved.
//

import SwiftUI

struct CountryDetailRow: View {
    
    var number: String = "Error"
    var name: String = "Confirm"
    var color: Color = .primary
    
    
    
    
    
    var body: some View {
        
        VStack {
            HStack {
                Text(self.name)
                    .font(.body)
                    .padding(5)
                
                Spacer()
                
                Text(self.number)
                .font(.subheadline)
                .padding(5)
                .foregroundColor(color)
            }
            Divider()
        }
    }
}

struct CountryDetailRow_Previews: PreviewProvider {
    static var previews: some View {
        CountryDetailRow()
    }
}
